#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct cache_line {
    long unsigned int tag;
    int valid, age;
} cache_line;

//global var
cache_line **cache;
int reads = 0, writes = 0, hits = 0, misses = 0;
//stats with prefetching
int p_reads = 0, p_writes = 0, p_hits = 0, p_misses = 0;
//assoc = number of blocks (cache lines) per set
int cache_size, block_size, block_offset, set_offset, num_sets, assoc;

//function declarations
void read(long unsigned int addr);
void write(long unsigned int addr);
void read_prefetch(long unsigned int addr);
void write_prefetch(long unsigned int addr);
void load_block(int set_num, long unsigned int tag, int invalid_i);

int main(int argc, char **argv) {

    //only process fifo caches
    if(strcmp(argv[3], "fifo") != 0)
        return EXIT_FAILURE;

    cache_size = atoi(argv[1]);
    if((cache_size <= 0) || ((cache_size & (cache_size - 1)) != 0))
        return EXIT_FAILURE;
    block_size = atoi(argv[4]);
    if((block_size <= 0) || ((block_size & (block_size - 1)) != 0))
        return EXIT_FAILURE;

    //direct mapped cache
    if(strcmp(argv[2], "direct") == 0) {
        assoc = 1;
        num_sets = cache_size / block_size;
    }
    //fully associative cache
    else if(strcmp(argv[2], "assoc") == 0) {
        num_sets = 1;
        assoc = cache_size / block_size;
    }
    //n-way associative cache
    else if(strncmp(argv[2], "assoc", 5) == 0) {
        char *n = argv[2] + 6;
        assoc = atoi(n);
        if((assoc <= 0) || ((assoc & (assoc - 1)) != 0))
            return EXIT_FAILURE;
        num_sets = cache_size / (assoc * block_size);
    }

    //compute block and set offsets
    //offset = log base 2 of size
    int n = block_size;
    while ((n >>= 1) != 0) {
        block_offset++;
    }
    n = num_sets;
    while ((n >>= 1) != 0) {
        set_offset++;
    }

    //num_sets = num rows, assoc = num cols
    cache = (cache_line**)malloc(num_sets * sizeof(cache_line*));
    cache[0] = (cache_line*)malloc(num_sets * assoc * sizeof(cache_line));
    for(int i = 0; i < num_sets; i++) {
        cache[i] = &cache[0][i * assoc];
        //init all cache lines to invalid
        for(int j = 0; j < assoc; j++) {
            cache[i][j].valid = 0;
        }
    }
    
    FILE *trace_file = fopen(argv[5], "r");
    if(trace_file == NULL)
        return EXIT_FAILURE;

    //read trace file
    long unsigned int addr;
    int ret = fscanf(trace_file, "%*x");
    //buffer to store R/W
    char buf[6];
    while(ret != EOF) {
        //read colon
        fscanf(trace_file, "%5s", buf);
        if(strcmp(buf, "#eof") == 0)
            break;
        //read R/W
        fscanf(trace_file, "%1s", buf);
        //read address
        fscanf(trace_file, "%lx", &addr);

        //printf("addr: %lx\n", addr);
        if(strcmp(buf, "R") == 0) {
            read(addr);
        }
        else if (strcmp(buf, "W") == 0) {
            write(addr);
        }

        //read next PC
        ret = fscanf(trace_file, "%*x");
    }

    //print output
    printf("Prefetch 0\n");
    printf("Memory reads: %d\n", reads);
    printf("Memory writes: %d\n", writes);
    printf("Cache hits: %d\n", hits);
    printf("Cache misses: %d\n", misses);

    //resest cache, simulate prefetching
    for(int i = 0; i < num_sets; i++) {
        for(int j = 0; j < assoc; j++) {
            cache[i][j].valid = 0;
            cache[i][j].tag = 0;
            cache[i][j].age = 0;
        }
    }
    FILE *p_trace_file = fopen(argv[5], "r");
    if(p_trace_file == NULL)
        {puts("prefetch fopen"); return EXIT_FAILURE;}
    
    ret = fscanf(p_trace_file, "%*x");
    while(ret != EOF) {
        //read colon
        fscanf(p_trace_file, "%5s", buf);
        if(strcmp(buf, "#eof") == 0)
            break;
        //read R/W
        fscanf(p_trace_file, "%1s", buf);
        //read address
        fscanf(p_trace_file, "%lx", &addr);

        if(strcmp(buf, "R") == 0) {
            read_prefetch(addr);
        }
        else if (strcmp(buf, "W") == 0) {
            write_prefetch(addr);
        }

        //read next PC
        ret = fscanf(p_trace_file, "%*x");
    }

    //print prefetch output
    printf("Prefetch 1\n");
    printf("Memory reads: %d\n", p_reads);
    printf("Memory writes: %d\n", p_writes);
    printf("Cache hits: %d\n", p_hits);
    printf("Cache misses: %d\n", p_misses);

    free(cache[0]);
    free(cache);

    return EXIT_SUCCESS;
}


//process a read request
void read(long unsigned int addr) {
    //index of line to replace: set to last invalid cache line
    int invalid_i = -1;
    long unsigned int tag = (addr >> block_offset);
    int set_num = tag & ((1 << set_offset) - 1);
    tag = tag >> set_offset;
    for(int i = 0; i < assoc; i++) {
        //cache[set_num][i] = cache line in set
        if(cache[set_num][i].valid == 0) {
            invalid_i = i;
        }
        else if(tag == cache[set_num][i].tag) {
            //addr found
            hits++;
            return;
        }
    }
    //addr not found: load new block from memory into cache
    reads++;
    misses++;
    load_block(set_num, tag, invalid_i);
}

//process a write request
void write(long unsigned int addr) {
    //index of line to replace: set to last invalid cache line
    int invalid_i = -1;
    long unsigned int tag = addr >> block_offset;
    int set_num = tag & ((1 << set_offset) - 1);
    tag = tag >> set_offset;
    for(int i = 0; i < assoc; i++) {
        if(cache[set_num][i].valid == 0) {
            invalid_i = i;
        }
        else if(tag == cache[set_num][i].tag) {
            //addr found
            writes++;
            hits++;
            return;
        }
    }
    //addr not found
    reads++;
    misses++;
    writes++;
    load_block(set_num, tag, invalid_i);
}

//process a read request w/prefetching
void read_prefetch(long unsigned int addr) {
    int invalid_i = -1;
    long unsigned int tag = addr >> block_offset;
    int set_num = tag & ((1 << set_offset) - 1);
    tag = tag >> set_offset;

    long unsigned int tag_next = (addr + block_size) >> block_offset;
    int set_num_next = tag_next & ((1 << set_offset) - 1);
    tag_next = tag_next >> set_offset;

    for(int i = 0; i < assoc; i++) {
        if(cache[set_num][i].valid == 0) {
            invalid_i = i;
        }
        else if(tag == cache[set_num][i].tag) {
            //addr found: do not load next block
            p_hits++;
            return;
        }
    }
    //addr not found: load addr
    p_reads++;
    p_misses++;
    load_block(set_num, tag, invalid_i);
    //find or load next block
    invalid_i = -1;
    for(int j = 0; j < assoc; j++) {
        if(cache[set_num_next][j].valid == 0) {
            invalid_i = j;
        }
        else if(tag_next == cache[set_num_next][j].tag) {
            return;
        }
    }
    p_reads++;
    load_block(set_num_next, tag_next, invalid_i);
}

//process a write request w/prefetching
void write_prefetch(long unsigned int addr) {
    int replace_i = -1;
    long unsigned int tag = addr >> block_offset;
    int set_num = tag & ((1 << set_offset) - 1);
    tag = tag >> set_offset;

    long unsigned int tag_next = (addr + block_size) >> block_offset;
    int set_num_next = tag_next & ((1 << set_offset) - 1);
    tag_next = tag_next >> set_offset;

    for(int i = 0; i < assoc; i++) {
        if(cache[set_num][i].valid == 0) {
            replace_i = i;
        }
        else if(tag == cache[set_num][i].tag) {
            p_writes++;
            p_hits++;
            return;
        }
    }
    //addr not found: load addr, then load next block
    p_writes++;
    p_reads++;
    p_misses++;
    load_block(set_num, tag, replace_i);
    replace_i = -1;
    for(int j = 0; j < assoc; j++) {
        if(cache[set_num_next][j].valid == 0) {
            replace_i = j;
        }
        else if(tag_next == cache[set_num_next][j].tag) {
            return;
        }
    }
    p_reads++;
    load_block(set_num_next, tag_next, replace_i);
}

//load addr (from memory) into a set
void load_block(int set_num, long unsigned int tag, int invalid_i) {
    //invalid_i is the index of the last invalid line in the set
    //if no invalid lines, replace oldest line
    int replace_i = invalid_i;
    if(invalid_i == -1) {
        //no invalid lines, find index of oldest cache line in set to replace
        replace_i = 0;
        for(int i = 0; i < assoc; i++) {
            if(cache[set_num][i].age > cache[set_num][replace_i].age) {
                replace_i = i;
            }
        }
    }
    cache[set_num][replace_i].valid = 1;
    cache[set_num][replace_i].tag = tag;
    cache[set_num][replace_i].age = 0;
    //update the ages of the other lines in the set
    for(int i = 0; i < assoc; i++) {
        if(i != replace_i && cache[set_num][i].valid == 1) {
            cache[set_num][i].age += 1;
        }
    }
}